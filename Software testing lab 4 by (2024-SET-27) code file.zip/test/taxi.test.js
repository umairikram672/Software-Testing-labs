import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import {
  fareForRide,
  totalFare,
  applyPeakSurcharge,
  waitingCharge,
  rideSummary,
  totalDistance,
} from '../src/taxi.js';

describe('R1 - fareForRide', () => {
  test('multiplies distance by rate for a whole-number fare', () => {
    // Arrange: 10 km at Rs 25/km -> 10 x 25 = 250
    const distanceKm = 10;
    const ratePerKm = 25;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert
    assert.strictEqual(result, 250);
  });

  test('rounds a half-rupee fare up to the nearest whole rupee', () => {
    // Arrange: 2.5 km at Rs 15/km -> 37.5 -> 38
    const distanceKm = 2.5;
    const ratePerKm = 15;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert
    assert.strictEqual(result, 38);
  });

  test('returns 0 for a zero-distance ride', () => {
    // Arrange: 0 km at Rs 30/km -> 0
    const distanceKm = 0;
    const ratePerKm = 30;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert
    assert.strictEqual(result, 0);
  });
});

describe('R2 - totalFare', () => {
  test('returns 0 for an empty list of rides', () => {
    // Arrange: no rides -> 0
    const rides = [];
    // Act
    const result = totalFare(rides);
    // Assert
    assert.strictEqual(result, 0);
  });

  test('adds the fares of several rides', () => {
    // Arrange: 10x25 = 250, 4x30 = 120 -> 370
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 4, ratePerKm: 30 },
    ];
    // Act
    const result = totalFare(rides);
    // Assert
    assert.strictEqual(result, 370);
  });

  test('rounds each ride fare (R1) before adding them', () => {
    // Arrange: 2.5x15 = 37.5 -> 38 per ride, 38 + 38 = 76 (not 75)
    const rides = [
      { distanceKm: 2.5, ratePerKm: 15 },
      { distanceKm: 2.5, ratePerKm: 15 },
    ];
    // Act
    const result = totalFare(rides);
    // Assert
    assert.strictEqual(result, 76);
  });
});

describe('R3 - applyPeakSurcharge', () => {
  test('increases the amount by 10 percent', () => {
    // Arrange: 200 + 10% of 200 (20) = 220
    const amount = 200;
    const percent = 10;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert
    assert.strictEqual(result, 220);
  });

  test('rounds a fractional result to the nearest whole rupee', () => {
    // Arrange: 99 + 10% of 99 (9.9) = 108.9 -> 109
    const amount = 99;
    const percent = 10;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert
    assert.strictEqual(result, 109);
  });

  test('leaves the amount unchanged for a 0 percent surcharge', () => {
    // Arrange: 100 + 0% = 100
    const amount = 100;
    const percent = 0;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert
    assert.strictEqual(result, 100);
  });
});

describe('R4 - waitingCharge', () => {
  test('charges nothing at 4 minutes (below the free limit)', () => {
    // Arrange: 4 min <= 5 free -> 0
    const minutes = 4;
    // Act
    const result = waitingCharge(minutes);
    // Assert
    assert.strictEqual(result, 0);
  });

  test('charges nothing at exactly 5 minutes (last free minute)', () => {
    // Arrange: 5 min <= 5 free -> 0
    const minutes = 5;
    // Act
    const result = waitingCharge(minutes);
    // Assert
    assert.strictEqual(result, 0);
  });

  test('charges Rs 10 at 6 minutes (first chargeable minute)', () => {
    // Arrange: (6 - 5) x 10 = 10
    const minutes = 6;
    // Act
    const result = waitingCharge(minutes);
    // Assert
    assert.strictEqual(result, 10);
  });

  test('charges Rs 100 for 15 minutes of waiting', () => {
    // Arrange: (15 - 5) x 10 = 100
    const minutes = 15;
    // Act
    const result = waitingCharge(minutes);
    // Assert
    assert.strictEqual(result, 100);
  });
});

describe('R5 - rideSummary', () => {
  test('combines fare, surcharge and waiting into a total', () => {
    // Arrange: fare 250+120 = 370; 10% -> 407 so surcharge 37;
    // 8 min wait -> (8-5) x 10 = 30; total 370+37+30 = 437
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 4, ratePerKm: 30 },
    ];
    // Act
    const result = rideSummary(rides, 10, 8);
    // Assert
    assert.deepStrictEqual(result, {
      fare: 370,
      surcharge: 37,
      waitingCharge: 30,
      total: 437,
    });
  });

  test('reports zero surcharge and zero waiting when neither applies', () => {
    // Arrange: fare 10x25 = 250; 0% -> surcharge 0; 5 min free -> 0; total 250
    const rides = [{ distanceKm: 10, ratePerKm: 25 }];
    // Act
    const result = rideSummary(rides, 0, 5);
    // Assert
    assert.deepStrictEqual(result, {
      fare: 250,
      surcharge: 0,
      waitingCharge: 0,
      total: 250,
    });
  });

  test('rounds the surcharge amount to whole rupees', () => {
    // Arrange: fare 250; 25% -> 312.5 -> 313 so surcharge 63; wait 6 -> 10;
    // total 250+63+10 = 323
    const rides = [{ distanceKm: 10, ratePerKm: 25 }];
    // Act
    const result = rideSummary(rides, 25, 6);
    // Assert
    assert.deepStrictEqual(result, {
      fare: 250,
      surcharge: 63,
      waitingCharge: 10,
      total: 323,
    });
  });
});

describe('R6 - totalDistance', () => {
  test('returns 0 for an empty list of rides', () => {
    // Arrange: no rides -> 0 km
    const rides = [];
    // Act
    const result = totalDistance(rides);
    // Assert
    assert.strictEqual(result, 0);
  });

  test('returns the distance of a single ride', () => {
    // Arrange: one ride of 7 km -> 7
    const rides = [{ distanceKm: 7, ratePerKm: 20 }];
    // Act
    const result = totalDistance(rides);
    // Assert
    assert.strictEqual(result, 7);
  });

  test('sums distanceKm across several rides', () => {
    // Arrange: 10 + 4 + 2.5 = 16.5
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 4, ratePerKm: 30 },
      { distanceKm: 2.5, ratePerKm: 15 },
    ];
    // Act
    const result = totalDistance(rides);
    // Assert
    assert.strictEqual(result, 16.5);
  });
});
