// src/taxi.js — Lab 04 taxi-fare module
// A "ride" is an object: { distanceKm, ratePerKm }

// R1: distanceKm x ratePerKm, rounded to the nearest whole rupee.
export function fareForRide(distanceKm, ratePerKm) {
  return Math.round(distanceKm * ratePerKm);
}

// R2: sum of R1 fares for every ride; empty list -> 0.
export function totalFare(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += fareForRide(ride.distanceKm, ride.ratePerKm);
  }
  return sum;
}

// R3: increase amount by percent, rounded to the nearest whole rupee.
export function applyPeakSurcharge(amount, percent) {
  return Math.round(amount + (amount * percent) / 100);
}

// R4: first 5 minutes free, every minute beyond 5 costs Rs 10.
export function waitingCharge(minutes) {
  if (minutes <= 5) {
    return 0;
  }
  return (minutes - 5) * 10;
}

// R5: { fare, surcharge, waitingCharge, total }
export function rideSummary(rides, surchargePercent, minutesWaited) {
  const fare = totalFare(rides);
  const surcharge = applyPeakSurcharge(fare, surchargePercent) - fare;
  const waiting = waitingCharge(minutesWaited);
  return {
    fare,
    surcharge,
    waitingCharge: waiting,
    total: fare + surcharge + waiting,
  };
}

// R6: sum of distanceKm across all rides; empty list -> 0.
export function totalDistance(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += ride.distanceKm;
  }
  return sum;
}
